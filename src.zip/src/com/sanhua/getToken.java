package com.sanhua;

import java.util.concurrent.TimeUnit;

public class getToken {
	public static String getTokenFromDb(){
		while(AsyncAccessToken.beingModified == true){
			try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return AsyncAccessToken.accessToken;
	}
		
}
