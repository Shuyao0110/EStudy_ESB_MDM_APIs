package com.sanhua;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ufida.eip.core.MessageContext;
import com.ufida.eip.exception.EIPException;
import com.ufida.eip.java.IContextProcessor;

public class personAPI implements IContextProcessor {
	
	public JSONObject deletePerson(String mdm_code) throws Exception{

        
        
		return null;
	}
	public JSONObject EStudySync(JSONArray data){
		//TODO ���ｫ����ƴ�ӣ���ʽƽ̨�ǵÿ�����������url
		try{
			String domain = "openapi-adel.yunxuetang.cn";
			String url = "https://"+ domain +"/v1/udp/public/users/sync/batch";
	    	URL uri = new URL(url);

	    	
	    	//TODO ������Eѧ���λ��token
	        //��װ��ѯ����
	        JSONObject queryCondition = new JSONObject();
	        queryCondition.put("datas", data);
	        //�������ӣ���������ͷ
	        HttpURLConnection connection = (HttpURLConnection) uri.openConnection();
	        connection.setRequestMethod("POST");
	        connection.setReadTimeout(50000);
	        connection.setConnectTimeout(100000);
	        connection.setDoInput(true); 
			connection.setDoOutput(true);
			//ʹ��tokenǰ��״̬��Ϊ1
	    	AsyncAccessToken.personUsing = true;
	    	String Authorization = getToken.getTokenFromDb();
			connection.setRequestProperty("Authorization", Authorization);
			connection.setRequestProperty("Content-type", "application/json; charset=utf-8");
	        connection.connect(); 
	        //TODO 
	        System.out.println(queryCondition.toString());
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(),"UTF-8"); 
	        writer.write(queryCondition.toString());
			writer.flush();
	        
			InputStream is = connection.getInputStream();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8")); 
			String strRead;
			StringBuffer sbf = new StringBuffer(); 
			while ((strRead = reader.readLine()) != null) {
				System.out.println(strRead);
				sbf.append(strRead); 
				sbf.append("\r\n"); 
			}
	        //����token�ָ�״̬
	        AsyncAccessToken.personUsing = false;
			reader.close();
			JSONObject results = new JSONObject(sbf.toString());
			
			return results;
		}
		catch(Exception e){
			return null;
		}
		
	}
	public ArrayList<String> getManagerIds(ArrayList<String> pkPostCodes){
		ArrayList<String> resultArray = new ArrayList<String>();
		try{
			String url = "http://10.10.201.40/iuapmdm/cxf/mdmrs/newcenter/newCenterService/queryListMdByMdmCodes";
	    	URL uri = new URL(url);
	    	
	    	//TODO ������Eѧ���λ��token
	        String mdmtoken = "9d2eeb88-c162-4214-9e86-e9c0fea9c6b2";
	        String tenantid = "tenant";
	        String systemCode = "EStudy-position";
	        String gdCode = "g_post_test";
	        //��װ��ѯ����
	        JSONObject queryCondition = new JSONObject();
	        queryCondition.put("systemCode", systemCode);
	        queryCondition.put("gdCode", gdCode);
	        queryCondition.put("pageable", false);
	        queryCondition.put("pageIndex", 1);
	        queryCondition.put("pageSize", 30000);
	        queryCondition.put("codes", pkPostCodes);
	        //�������ӣ���������ͷ
	        HttpURLConnection connection = (HttpURLConnection) uri.openConnection();
	        connection.setRequestMethod("POST");
	        connection.setReadTimeout(50000);
	        connection.setConnectTimeout(100000);
	        connection.setDoInput(true); 
			connection.setDoOutput(true); 
			connection.setRequestProperty("mdmtoken", mdmtoken);
			connection.setRequestProperty("tenantid", tenantid);
			connection.setRequestProperty("Content-type", "application/json");
	        connection.connect(); 
	        //TODO 
	        System.out.println(queryCondition.toString());
	        OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(),"UTF-8"); 
	        writer.write(queryCondition.toString()); 
			writer.flush();
	        
			InputStream is = connection.getInputStream();
	        BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8")); 
			String strRead;
			StringBuffer sbf = new StringBuffer(); 
			while ((strRead = reader.readLine()) != null) {
				System.out.println(strRead);
				sbf.append(strRead); 
				sbf.append("\r\n"); 
			}
			reader.close();
			JSONObject results = new JSONObject(sbf.toString());
			//�������������֣�Eѧ�����еĸ�λ���࣡ 2023-8-3 ����������������ǵ������쳣����
			JSONArray resultData = results.getJSONArray("data");
			JSONObject pkMapping = new JSONObject();
			ArrayList<String> personCondition = new ArrayList<String>();
			personCondition.add("and");
			personCondition.add("in");
			for(int i = 0; i < resultData.length(); i++){
				JSONObject oneResultData = resultData.getJSONObject(i);
				String pk_mdm_code = oneResultData.getString("mdm_code");
				String pk_post_name = oneResultData.getString("code");
				pkMapping.put(pk_mdm_code, pk_post_name);
				personCondition.add("'" + pk_post_name + "'");
			}
			
			//TODO ��һ�β�ѯ��Eѧ��Ա����Ϣ
			try{
				url = "http://10.10.201.40/iuapmdm/cxf/mdmrs/newcenter/newCenterService/queryListMdByConditions";
		    	uri = new URL(url);
		    	
		    	//TODO ������Eѧ���λ��token
		        mdmtoken = "272f9d08-5b39-40d1-a53f-8b45a8b7c89a";
		        tenantid = "tenant";
		        systemCode = "EStudy-person";
		        gdCode = "g_pers_test";
		        //��װ��ѯ����
		        queryCondition = new JSONObject();
		        JSONObject conditions = new JSONObject();
		        conditions.put("pk_post#code", personCondition);
		        queryCondition.put("systemCode", systemCode);
		        queryCondition.put("gdCode", gdCode);
		        queryCondition.put("pageable", false);
		        queryCondition.put("pageIndex", 1);
		        queryCondition.put("pageSize", 30000);
		        queryCondition.put("conditions", conditions);
		        //�������ӣ���������ͷ
		        connection = (HttpURLConnection) uri.openConnection();
		        connection.setRequestMethod("POST");
		        connection.setReadTimeout(50000);
		        connection.setConnectTimeout(100000);
		        connection.setDoInput(true); 
				connection.setDoOutput(true); 
				connection.setRequestProperty("mdmtoken", mdmtoken);
				connection.setRequestProperty("tenantid", tenantid);
				connection.setRequestProperty("Content-type", "application/json");
		        connection.connect(); 
		        System.out.println(queryCondition.toString());
		        writer = new OutputStreamWriter(connection.getOutputStream(),"UTF-8"); 
		        writer.write(queryCondition.toString()); 
				writer.flush();
		        
				is = connection.getInputStream();
		        reader = new BufferedReader(new InputStreamReader(is, "UTF-8")); 
				sbf = new StringBuffer(); 
				while ((strRead = reader.readLine()) != null) {
					System.out.println(strRead);
					sbf.append(strRead); 
					sbf.append("\r\n"); 
				}
				reader.close();
				results = new JSONObject(sbf.toString());
			}
			catch(Exception e){
				System.out.println("��������ƽ̨��ѯ��Ա��Ϣʱ���ִ���");
			}
			//�˴�try���ڴ����������쳣����������Ա���ϼ�������Ҫͬ��
			JSONArray personResult = new JSONArray();
			try{
				personResult = results.getJSONArray("data");
			}
			catch (Exception e){
				System.out.println("������Ա�����ϼ���");
			}
			JSONObject codeMdmCodeMapping = new JSONObject();
			for(int i = 0; i < personResult.length(); i++){
				JSONObject oneData = personResult.getJSONObject(i);
				String onePostCode = oneData.getString("pk_post_name");
				String oneMdmCode = oneData.getString("mdm_code");
				codeMdmCodeMapping.put(onePostCode, oneMdmCode);
			}
			
			Iterator<String> iterator = pkPostCodes.iterator();
			while(iterator.hasNext()){
				//�˴�try���ڴ�����Ա�ϼ�����ͬ�����쳣
				try{
					String pkPostCode = iterator.next();
					String managerMdmCode = codeMdmCodeMapping.getString(pkMapping.getString(pkPostCode));
					resultArray.add(managerMdmCode);
				}
				catch (Exception e){
					resultArray.add(null);
				}
			}
		}
		catch (Exception e){
			e.printStackTrace();
		}
		return resultArray;
	}
	//���ڴ�����֤��ת����
	public String getBirthDay(String id){
		String birthdayDate = id.substring(6, 14);
		String birthdayYear = birthdayDate.substring(0, 4);
		String birthdayMonth = birthdayDate.substring(4, 6);
		String birthdayDay = birthdayDate.substring(6, 8);
		String birthday = birthdayYear + "-" + birthdayMonth + "-" + birthdayDay;
		return birthday;
	}
	@Override
	public String handleMessageContext(MessageContext arg0) throws EIPException {
		// TODO Auto-generated method stub
		JSONObject personMdmData = new JSONObject(arg0.getBodyData().toString());
		String entityCode = personMdmData.getString("mdType");
		JSONArray personMasterData = new JSONArray(personMdmData.getString("masterData"));
		//ͬ������
		System.out.println(personMasterData.toString());
		JSONArray dataToEStudy = new JSONArray();
		//��ְ����
		ArrayList<String> dataDelEstudy = new ArrayList<String>();
		//����������ְ��񣬲������ְ��Ա���ϼ���λ�����ݱ���
		ArrayList<String> syncMdmCodes = new ArrayList<String>();
		ArrayList<String> pkPostCodes = new ArrayList<String>();
		ArrayList<String> mdmCodes = new ArrayList<String>();
		
		Iterator<Object> iterator = personMasterData.iterator();
		//TODO ��ԱһСʱֻ����ͬ��һ�Σ���Ҫ��Ϊ�ݹ�ʽͬ�� 2023-8-4
//		//��һ��ͬ��
//		while(iterator.hasNext()){
//			JSONObject onePersonMasterData = (JSONObject) iterator.next();
//			String peopleStatus = onePersonMasterData.getJSONObject("peop_status_entity").getString("code");
//			String mdm_code = onePersonMasterData.getString("mdm_code");
//			mdmCodes.add(mdm_code);
//			if(!peopleStatus.equals("01")){
//				dataDelEstudy.add(mdm_code);
//				iterator.remove();;//���ｫ����ְ��Ա���Ƴ�
//				continue;
//			}
//			String pk_post_code = onePersonMasterData.getJSONObject("pk_post_entity").getString("pk_post");
//			syncMdmCodes.add(mdm_code);
//			pkPostCodes.add(pk_post_code);
//		}
//		ArrayList<String> managerCodes = getManagerIds(pkPostCodes);
//		
//		for(int i = 0; i < personMasterData.length(); i++){
//			JSONObject oneData = new JSONObject();
//			JSONObject onePersonMasterData = personMasterData.getJSONObject(i);
//			
//			String thirdUserId = syncMdmCodes.get(i);
//			String username = onePersonMasterData.getString("last_code");
//			String fullname = onePersonMasterData.getString("name");
//			
//			oneData.put("thirdUserId",thirdUserId);
//			oneData.put("username",username);
//			oneData.put("fullname",fullname);
//			dataToEStudy.put(oneData);
//		}
//		JSONObject result = EStudySync(dataToEStudy);
//		System.out.println(result.toString());
//		//String successOrNot = result.getString("msg");

		//�ڶ���ͬ��
		
		iterator = personMasterData.iterator();
		while(iterator.hasNext()){
			JSONObject onePersonMasterData = (JSONObject) iterator.next();
			String peopleStatus = onePersonMasterData.getJSONObject("peop_status_entity").getString("code");
			String mdm_code = onePersonMasterData.getString("mdm_code");
			if(!peopleStatus.equals("01")){
				dataDelEstudy.add(mdm_code);
				iterator.remove();;//���ｫ����ְ��Ա���Ƴ�
				continue;
			}
			String pk_post_code = onePersonMasterData.getJSONObject("pk_post_entity").getString("pk_post");
			syncMdmCodes.add(mdm_code);
			pkPostCodes.add(pk_post_code);
		}
		dataToEStudy = new JSONArray();
		for(int i = 0; i < personMasterData.length(); i++){
			JSONObject oneData = new JSONObject();
			JSONObject onePersonMasterData = personMasterData.getJSONObject(i);
			
			String thirdUserId = syncMdmCodes.get(i);
			String username = onePersonMasterData.getString("last_code");
			String fullname = onePersonMasterData.getString("name");
			String userNo = onePersonMasterData.getString("last_code");
			String hireDate = onePersonMasterData.getString("entry_time");
			String gender = onePersonMasterData.getString("sex");
			int genderInd = 0;
			if(gender.equals("01")){
				genderInd = 1;
			}
			else if(gender.equals("02")){
				genderInd = 2;
			}
			String birthday = getBirthDay(onePersonMasterData.getString("id_munb"));
			String email = onePersonMasterData.getString("mail_addr");
			String positionThirdId = onePersonMasterData.getJSONObject("pk_post_entity").getString("mdm_code");
			
			String deptThirdId = onePersonMasterData.getJSONObject("pk_post_entity").getString("pk_org");
			//��������Ҫ�������ݣ���ʱû��
			//String parttimeDeptThirdIds = "";
			//String parttimePositionThirdIds = "";
			String managerThirdId = managerCodes.get(i);
			oneData.put("thirdUserId",thirdUserId);
			oneData.put("username",username);
			oneData.put("fullname",fullname);
			oneData.put("userNo",userNo);
			oneData.put("hireDate",hireDate);
			//oneData.put("gender",genderInd);
			oneData.put("birthday",birthday);
			oneData.put("email",email);
			oneData.put("positionThirdId",positionThirdId);
			oneData.put("deptThirdId",deptThirdId);
			//oneData.put("parttimePositionThirdIds",parttimePositionThirdIds);
			//oneData.put("parttimeDeptThirdIds",parttimeDeptThirdIds);
			//oneData.put("managerThirdId",managerThirdId);
			dataToEStudy.put(oneData);
		}
		result = EStudySync(dataToEStudy);
		System.out.println(result.toString());
		
		return null;
	}

}
