package com.sanhua;

public class positiontype {

}
